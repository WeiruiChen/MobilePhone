(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/plugin/home"],{"06b3":function(t,n,e){"use strict";var i;e.d(n,"b",(function(){return u})),e.d(n,"c",(function(){return l})),e.d(n,"a",(function(){return i}));var u=function(){var t=this,n=t.$createElement;t._self._c},l=[]},"1d7c":function(t,n,e){"use strict";var i=e("4041"),u=e.n(i);u.a},4041:function(t,n,e){},"74e59":function(t,n,e){"use strict";(function(t){Object.defineProperty(n,"__esModule",{value:!0}),n.default=void 0;var e={name:"components",data:function(){return{StatusBar:this.StatusBar,CustomBar:this.CustomBar,list:[{title:"索引列表",img:"https://image.weilanwl.com/color2.0/plugin/sylb2244.jpg",url:"../plugin/indexes"},{title:"微动画",img:"https://image.weilanwl.com/color2.0/plugin/wdh2236.jpg",url:"../plugin/animation"},{title:"全屏抽屉",img:"https://image.weilanwl.com/color2.0/plugin/qpct2148.jpg",url:"../plugin/drawer"},{title:"垂直导航",img:"https://image.weilanwl.com/color2.0/plugin/qpczdh2307.jpg",url:"../plugin/verticalnav"}]}},methods:{toChild:function(n){t.navigateTo({url:n.currentTarget.dataset.url})}}};n.default=e}).call(this,e("543d")["default"])},b396:function(t,n,e){"use strict";e.r(n);var i=e("74e59"),u=e.n(i);for(var l in i)"default"!==l&&function(t){e.d(n,t,(function(){return i[t]}))}(l);n["default"]=u.a},b4c4:function(t,n,e){"use strict";e.r(n);var i=e("06b3"),u=e("b396");for(var l in u)"default"!==l&&function(t){e.d(n,t,(function(){return u[t]}))}(l);e("1d7c");var a,r=e("f0c5"),c=Object(r["a"])(u["default"],i["b"],i["c"],!1,null,null,null,!1,i["a"],a);n["default"]=c.exports}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/plugin/home-create-component',
    {
        'pages/plugin/home-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("b4c4"))
        })
    },
    [['pages/plugin/home-create-component']]
]);
