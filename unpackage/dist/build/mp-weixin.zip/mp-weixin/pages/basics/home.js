(global["webpackJsonp"]=global["webpackJsonp"]||[]).push([["pages/basics/home"],{"3e71":function(n,e,o){},"458e":function(n,e,o){"use strict";o.r(e);var t=o("d5de"),c=o.n(t);for(var a in t)"default"!==a&&function(n){o.d(e,n,(function(){return t[n]}))}(a);e["default"]=c.a},"5d96":function(n,e,o){"use strict";o.r(e);var t=o("a80f"),c=o("458e");for(var a in c)"default"!==a&&function(n){o.d(e,n,(function(){return c[n]}))}(a);o("a3fd");var l,u=o("f0c5"),r=Object(u["a"])(c["default"],t["b"],t["c"],!1,null,null,null,!1,t["a"],l);e["default"]=r.exports},a3fd:function(n,e,o){"use strict";var t=o("3e71"),c=o.n(t);c.a},a80f:function(n,e,o){"use strict";var t;o.d(e,"b",(function(){return c})),o.d(e,"c",(function(){return a})),o.d(e,"a",(function(){return t}));var c=function(){var n=this,e=n.$createElement;n._self._c},a=[]},d5de:function(n,e,o){"use strict";Object.defineProperty(e,"__esModule",{value:!0}),e.default=void 0;var t={name:"basics",data:function(){return{elements:[{title:"布局",name:"layout",color:"cyan",cuIcon:"newsfill"},{title:"背景",name:"background",color:"blue",cuIcon:"colorlens"},{title:"文本",name:"text",color:"purple",cuIcon:"font"},{title:"图标 ",name:"icon",color:"mauve",cuIcon:"cuIcon"},{title:"按钮",name:"button",color:"pink",cuIcon:"btn"},{title:"标签",name:"tag",color:"brown",cuIcon:"tagfill"},{title:"头像",name:"avatar",color:"red",cuIcon:"myfill"},{title:"进度条",name:"progress",color:"orange",cuIcon:"icloading"},{title:"边框阴影",name:"shadow",color:"olive",cuIcon:"copy"},{title:"加载",name:"loading",color:"green",cuIcon:"loading2"}]}},onShow:function(){console.log("success")}};e.default=t}}]);
;(global["webpackJsonp"] = global["webpackJsonp"] || []).push([
    'pages/basics/home-create-component',
    {
        'pages/basics/home-create-component':(function(module, exports, __webpack_require__){
            __webpack_require__('543d')['createComponent'](__webpack_require__("5d96"))
        })
    },
    [['pages/basics/home-create-component']]
]);
